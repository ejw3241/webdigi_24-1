var menuItems = document.querySelectorAll('.horizontalNAV li');

menuItems.forEach(function(item) {
    item.addEventListener('click', function() {
        var submenu = this.querySelector('.submenu');
        if (submenu) {
            submenu.style.display = (submenu.style.display === 'block') ? 'none' : 'block';
        }
    });
});